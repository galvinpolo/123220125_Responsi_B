/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model.Alat;

/**
 *
 * @author Lab Informatika
 */
public class ModelAlat {
    private Integer id, notelf, waktusewa, biayasewa;
    private String alat, nama;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getNotelf() {
        return notelf;
    }

    public void setNotelf(Integer notelf) {
        this.notelf = notelf;
    }

    public Integer getWaktusewa() {
        return waktusewa;
    }

    public void setWaktusewa(Integer waktusewa) {
        this.waktusewa = waktusewa;
    }

    public Integer getBiayasewa() {
        return biayasewa;
    }

    public void setBiayasewa(Integer biayasewa) {
        this.biayasewa = biayasewa;
    }

    public String getAlat() {
        return alat;
    }

    public void setAlat(String alat) {
        this.alat = alat;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }
    
    
}
