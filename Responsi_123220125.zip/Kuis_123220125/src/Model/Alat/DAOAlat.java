/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model.Alat;

import Connector.Connector;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Lab Informatika
 */
public class DAOAlat implements InterfaceDAOAlat{

    @Override
    public void insert(ModelAlat alat) {
        try{
            String query = "INSERT INTO alat (nama, alat, notelf, waktusewa, biaya) VALUES (?, ?, ?, ?, ?);";
            
            PreparedStatement statement;
            statement = Connector.Connect().prepareStatement(query);
            statement.setString(1, alat.getNama());
            statement.setString(2, alat.getAlat());
            statement.setInt(3, alat.getNotelf());
            statement.setInt(4, alat.getWaktusewa());
            statement.setInt(5, alat.getBiayasewa());
            
            statement.executeUpdate();
            
            statement.close();
        } catch (SQLException e) {
            System.out.println("Input Failed: " + e.getLocalizedMessage());
        }
    }

    @Override
    public void update(ModelAlat alat) {
        try {
        String query = "UPDATE alat SET nama=?, alat=?, notelf=?, waktusewa=?, biaya=?  WHERE id=?;";
            
        PreparedStatement statement;
        statement = Connector.Connect().prepareStatement(query);
        statement.setString(1, alat.getNama());
        statement.setString(2, alat.getAlat());
        statement.setInt(3, alat.getNotelf());
        statement.setInt(4, alat.getWaktusewa());
        statement.setInt(5, alat.getBiayasewa());
        
        statement.executeUpdate();
        
        statement.close();
    } catch (SQLException e) {
        System.out.println("update Failed! (" + e.getMessage() + ")");
    }
    }

    @Override
    public void delete(int id) {
        try {
            String query = "DELETE FROM alat WHERE id=?;";
            
            PreparedStatement statement;
            statement = Connector.Connect().prepareStatement(query);
            statement.setInt(1, id);
            
            statement.executeUpdate();
            
            statement.close();
        } catch (SQLException e) {
            System.out.println("Delete Failed: " + e.getLocalizedMessage());
        }
    }

    @Override
    public List<ModelAlat> getAll() {
        List<ModelAlat> listAlat = null;

        try {
            listAlat = new ArrayList<>();
            
            Statement statement = Connector.Connect().createStatement();
            
            String query = "SELECT * FROM alat;";
            
            ResultSet resultSet = statement.executeQuery(query);
            
            while (resultSet.next()) {
                ModelAlat mhs = new ModelAlat();
                
                mhs.setId(resultSet.getInt("id"));
                mhs.setNama(resultSet.getString("nama"));
                mhs.setAlat(resultSet.getString("alat"));
                mhs.setNotelf(resultSet.getInt("notelf"));
                mhs.setWaktusewa(resultSet.getInt("waktusewa"));
                mhs.setBiayasewa(resultSet.getInt("biaya"));
                
                listAlat.add(mhs);
            }
            
            statement.close();
        } catch (SQLException e) {
            System.out.println("Error: " + e.getLocalizedMessage());
        }
        return listAlat;
    }
   
}
