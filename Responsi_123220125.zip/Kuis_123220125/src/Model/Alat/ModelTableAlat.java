/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model.Alat;

import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author Lab Informatika
 */
public class ModelTableAlat extends AbstractTableModel{
     List<ModelAlat> daftarAlat;
    String kolom[] = {"ID","Nama","Alat","Nomor Telefon", "Waktu Sewa", "Biaya"};
    
    public ModelTableAlat(List<ModelAlat> daftarAlat){
        this.daftarAlat = daftarAlat;
    }

    @Override
    public int getRowCount() {
        return daftarAlat.size();
    }

    @Override
    public int getColumnCount() {
        return kolom.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        switch (columnIndex){
            case 0:
                return daftarAlat.get(rowIndex).getId();
            case 1:
                return daftarAlat.get(rowIndex).getNama();
            case 2:
                return daftarAlat.get(rowIndex).getAlat();
            case 3:
                return daftarAlat.get(rowIndex).getNotelf();
            case 4:
                return daftarAlat.get(rowIndex).getWaktusewa();
            case 5:
                return daftarAlat.get(rowIndex).getBiayasewa();
            default:
                return null;
        }
    }

    @Override
    public String getColumnName(int columnIndex) {
        return kolom[columnIndex];
    }
    
}
