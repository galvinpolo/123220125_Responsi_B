/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Model.Alat;

import java.util.List;

/**
 *
 * @author Lab Informatika
 */
public interface InterfaceDAOAlat {
    public void insert(ModelAlat alat);
    
    public void update(ModelAlat alat);
    
    public void delete(int id);
    
    // Method untuk mengambil data dosen
    public List<ModelAlat> getAll();
}
