/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Model.Alat.*;
import View.Alat.*;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author Lab Informatika
 */
public class ControllerAlat {
   ViewAlat tabelAlat;
    InputAlat inputAlat;
    EditAlat editAlat;
    
    InterfaceDAOAlat daoAlat;
    
    List<ModelAlat> listAlat;

    public ControllerAlat(ViewAlat tabelAlat) {
        this.tabelAlat = tabelAlat;
        this.daoAlat = new DAOAlat();
    }

    public ControllerAlat(InputAlat inputAlat) {
        this.inputAlat = inputAlat;
        this.daoAlat = new DAOAlat();
    }

    public ControllerAlat(EditAlat editAlat) {
        this.editAlat = editAlat;
        this.daoAlat = new DAOAlat();
    }
    
    public void showAllAlat(){
        listAlat = daoAlat.getAll();
        ModelTableAlat tabel = new ModelTableAlat(listAlat);
        tabelAlat.getTableAlat().setModel(tabel);
    }
    
    public void insertAlat(){
        try{
            ModelAlat baru = new ModelAlat();
            
            String nama = inputAlat.getInputNama();
            String alat = inputAlat.getInputAlat();
            String notelf = inputAlat.getInputNotelf();
            Integer notelfint = Integer.parseInt(notelf);
            String waktuSewa = inputAlat.getInputWaktusewa();
            Integer waktuint = Integer.parseInt(waktuSewa);
            String biaya = inputAlat.getInputBiaya();
            Integer biayaint = Integer.parseInt(biaya);

            baru.setNama(nama);
            baru.setAlat(alat);
            baru.setNotelf(notelfint);
            baru.setWaktusewa(waktuint);
            baru.setBiayasewa(biayaint);
            
            daoAlat.insert(baru);
            JOptionPane.showMessageDialog(null, "Berhasil menambahkan alat");
            inputAlat.dispose();
            new ViewAlat();
            }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
    }
    
    public void editAlat(int id){
        try{
        ModelAlat AlatDiedit = new ModelAlat();
        
        String nama = inputAlat.getInputNama();
            String alat = inputAlat.getInputAlat();
            String notelf = inputAlat.getInputNotelf();
            Integer notelfint = Integer.parseInt(notelf);
            String waktuSewa = inputAlat.getInputWaktusewa();
            Integer waktuint = Integer.parseInt(waktuSewa);
            String biaya = inputAlat.getInputBiaya();
            Integer biayaint = Integer.parseInt(biaya);
        
        if("".equals(nama) || "".equals(alat)){
            throw new Exception("Nama atau Alat tidak boleh kosong");
        }
        
        AlatDiedit.setId(id);
        AlatDiedit.setNama(nama);
        AlatDiedit.setAlat(alat);
        AlatDiedit.setNotelf(notelfint);
        AlatDiedit.setWaktusewa(waktuint);
        AlatDiedit.setBiayasewa(biayaint);
        
        daoAlat.update(AlatDiedit);
        
        JOptionPane.showMessageDialog(null, "Berhasil mengubah data Alat");
        
        editAlat.dispose();
        new ViewAlat();
        } catch(Exception e){
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
    }
    
    
    public void deleteAlat(int baris){
        Integer id = (int) tabelAlat.getTableAlat().getValueAt(baris, 0);
        String nama = tabelAlat.getTableAlat().getValueAt(baris, 1).toString();

        int input = JOptionPane.showConfirmDialog(
                null,
                "Hapus " + nama + "?",
                "Hapus Alat",
                JOptionPane.YES_NO_OPTION
        );

        if (input == 0) {
            daoAlat.delete(id);
            
            JOptionPane.showMessageDialog(null, "Berhasil menghapus data.");

            showAllAlat();
        }
    }
    
}
