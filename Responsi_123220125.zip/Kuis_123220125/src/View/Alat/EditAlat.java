package View.Alat;

import Controller.ControllerAlat;
import Model.Alat.ModelAlat;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class EditAlat extends JFrame {
    ControllerAlat controller;
    
    JLabel header = new JLabel("Edit Alat");
    JLabel labelInputNama = new JLabel("Nama");
    JLabel labelInputAlat = new JLabel("Alat");
    JTextField inputNama = new JTextField();
    JTextField inputAlat = new JTextField();
    JLabel labelInputNotelf = new JLabel("Notelf");
    JTextField inputNotelf = new JTextField();
    JLabel labelInputWaktuSewa = new JLabel("WaktuSewa");
    JTextField inputWaktuSewa = new JTextField();
    JLabel labelInputBiaya = new JLabel("Biaya");
    JTextField inputBiaya = new JTextField();
    
    JButton tombolEdit = new JButton("Edit Alat");
    JButton tombolKembali = new JButton("Kembali");

    public EditAlat(ModelAlat Alat) {
        setTitle("Edit Alat");
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);
        setSize(480, 540);
        setLocationRelativeTo(null);

       add(header);
        add(labelInputNama);
        add(labelInputAlat);
        add(labelInputNotelf);
        add(labelInputWaktuSewa);
        add(labelInputBiaya);
        add(inputNama);
        add(inputAlat);
        add(inputNotelf);
        add(inputWaktuSewa);
        add(inputBiaya);
        add(tombolEdit);
        add(tombolKembali);

        header.setBounds(20, 8, 440, 24);
        labelInputNama.setBounds(20, 32, 440, 24);
        inputNama.setBounds(18, 56, 440, 36);
        
        labelInputAlat.setBounds(20, 96, 440, 24);
        inputAlat.setBounds(18, 120, 440, 36);
        
        labelInputNotelf.setBounds(20, 156, 440, 24);
        inputNotelf.setBounds(18, 180, 440, 36);
        
        labelInputWaktuSewa.setBounds(20, 216, 440, 24);
        inputWaktuSewa.setBounds(18, 240, 440, 36);
        
        labelInputBiaya.setBounds(20, 276, 440, 24);
        inputBiaya.setBounds(18, 300, 440, 36);
        
        tombolKembali.setBounds(20, 350, 215, 40);
        tombolEdit.setBounds(240, 350, 215, 40);
        
        inputNama.setText(Alat.getNama());
        inputAlat.setText(Alat.getAlat());
        
        controller = new ControllerAlat(this);

        tombolKembali.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                new ViewAlat();
            }
        });

        tombolEdit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                controller.editAlat(Alat.getId());
            }
        });
    }
    
    public String getInputNama() {
        return inputNama.getText();
    }
    
    public String getInputAlat() {
        return inputAlat.getText();
    }

    public void setID() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
